# 04 — Threat model and privacy

## Assets

Protected signing keys; correct identity-to-device registration; authentic software/firmware provenance; true observations; community permission; members' privacy; reliable history and availability.

## Threats and controls

| Threat | v0.1 protection | Required for real deployment |
|---|---|---|
| Readings changed in transit | Ed25519 + event hash detect alteration | Independent authenticated public key / registry |
| Sequence changed or events reordered | Linked hashes and monotonic event sequence within supplied stream | Independently witnessed log heads; replay/fork detection |
| Signing private key stolen | None (software demo) | Secure element key protection; revocation; attestation |
| Falsified observation by authorised device | None | Calibration, independent witness, protected sensor path |
| Host clock manipulated | None | Trusted timestamping or independent ordering service |
| Rogue hardware swapped in | Fingerprint mismatch if registry trusted | Secure enrolment, challenge-response and hardware identity |
| Compromised firmware lies | None | Secure/measured boot and authenticated device state |
| Unauthorized action | None | Explicit bounded authorization and physical safety constraints |
| Bad/inappropriate community governance | None | Transparent policies, separation of duties, appeal mechanisms |
| Power loss / counter rollback | Chain can reveal only some local inconsistencies | Persistent monotonic counter / witnessed high-water marks |
| Privacy leakage from sensor data | Example uses non-personal simulated data | Purpose limitation, aggregation, local storage, retention policy |
| Supply-chain or implementation vulnerabilities | None | Vendor and build review, reproducibility, vulnerability handling |

## Security rules for contributors

- Never accept a device public key as *trusted* merely because it is attached to a signed event.
- Never represent cryptographic signatures as proof that reality was observed correctly.
- Never call the educational RTL counter hardware-secure: its reset resets the value.
- Use nonce-based challenges, device-specific enrolment, signed trusted registries and revocation before making operational trust decisions.
- Consider ed25519 migration, multi-signature witnesses and post-quantum requirements as the system evolves; do not invent a custom cryptographic algorithm.
- Default to public data minimisation. Signed observations may still reveal sensitive patterns.
- For physical actuator control, keep separate safety interlocks and human oversight.

## Minimal privacy model

- Device identity is pseudonymous, not anonymous. Linkability and inference remain possible.
- The demo does not transmit information over a network.
- Device owner and community should set visibility, retention period and correction/appeal processes.
- Where on-chain commitments are justified, anchor hashes/aggregates, not personal raw observations.

# 08 — References and tools

Checked for project orientation on **16 November 2026**. These sources are external and may change; independently confirm availability, revisions and licenses before implementing.

| Resource | Purpose | Link |
|---|---|---|
| OpenTitan | Open-source silicon root of trust reference and design documentation | https://opentitan.org/documentation/ |
| OpenTitan Cryptolib | Current list of algorithms including Ed25519 | https://opentitan.org/book/doc/security/cryptolib/cryptolib_api.html |
| TROPIC01 product page | Ed25519/P-256 and hardware capabilities | https://www.tropicsquare.com/tropic01 |
| TROPIC01 documentation | Devboard/USB/SPI documentation and design resources | https://www.tropicsquare.com/documentation |
| TROPIC01 RTL | Published implementation artefacts and limitations | https://github.com/tropicsquare/tropic01 |
| libtropic | Vendor C SDK; inspect compatible firmware versions | https://github.com/tropicsquare/libtropic |
| libtropic PKCS#11 | Existing experimental protected-key interface | https://github.com/tropicsquare/libtropic-pkcs11 |
| OpenROAD | Open-source physical design | https://openroad.readthedocs.io/en/latest/main/README.html |
| OpenROAD Flow Scripts | Supported open PDK flow targets | https://openroad-flow-scripts.readthedocs.io/ |
| Tiny Tapeout | Small-scale learning and shared chip fabrication | https://tinytapeout.com/ |
| SkyWater SKY130 | Open 130 nm PDK | https://github.com/google/skywater-pdk |
| GlobalFoundries GF180MCU | Open 180 nm PDK | https://github.com/google/gf180mcu-pdk |
| IHP SG13G2 | Open SiGe BiCMOS platform | https://github.com/IHP-GmbH/IHP-Open-PDK |
| Node.js Crypto | Local demo signing and signature verification | https://nodejs.org/api/crypto.html |
| Web Crypto API | Browser verification support / platform variations | https://developer.mozilla.org/en-US/docs/Web/API/Web_Crypto_API |

## Notes

- Some projects expose RTL but not every foundry macro, boot ROM, analogue component, process IP or manufacturing step. 'Open silicon' does not necessarily mean a wholly reproducible chip in any fab.
- TROPIC01 documentation must be reviewed against the precise hardware revision, SDK and firmware combination selected.
- Educational tapeout costs and queue availability are time-sensitive; no price or date is promised by this kit.

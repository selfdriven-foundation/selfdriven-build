# 02 — Architecture

## Separation of responsibilities

```text
                        COMMUNITY GOVERNANCE
                     enrol / revoke / authorise
                               │
┌──────────────────────────────┼──────────────────────────────┐
│ Community app / Octo / UI    │  (policy + human decisions)   │
├──────────────────────────────┼──────────────────────────────┤
│ Observation provider         │  (meter / sensor / operator)  │
├──────────────────────────────┼──────────────────────────────┤
│ Evidence formatter           │  (canonical body, sequence)  │
├──────────────────────────────┼──────────────────────────────┤
│ Signer adapter                │  (software / secure element) │
├──────────────────────────────┼──────────────────────────────┤
│ Verifier + registry          │  (integrity, issuer, policy) │
├──────────────────────────────┼──────────────────────────────┤
│ VCG / storage / OnChain       │  (provenance + commitments)  │
└──────────────────────────────┴──────────────────────────────┘
```

A signed event can be **cryptographically valid** while still being **untrusted**. Hardware provenance, enrolment authority, valid calibration, timestamp provenance and community permission are different checks.

## Roles

- **Device:** physical or simulated source of actions/observations.
- **Host:** software controlling the device and constructing signed data.
- **Signer:** key holder; initially Node.js in-memory; eventually a secure element.
- **Issuer/enroller:** community-approved authority mapping a key to a device.
- **Verifier:** independently validates signatures and hash-chain continuity.
- **Validator:** makes domain-specific assertions such as sensor calibration or witness agreement.
- **Community:** decides policy, consent, oversight, and which outcomes to trust.

## Signer interface (proposed)

```javascript
const signer = {
  deviceId: 'sdid:spki256:...',
  publicKeySpki: 'base64url DER SPKI',
  signerType: 'hardware-attested', // only AFTER authentic verification
  sign: messageBytes => Promise.resolve(signatureBytes)
};
```

The current `src/protocol.js` signer is synchronous and uses `signerType: 'software-demo'`. Adapting to hardware involves an asynchronous transport, key enrolment, a stable key-handle scheme, a device certificate or manufacturer identity verification where applicable, and a signed registry maintained separately from the observations. No hardware adapter is implemented yet.

## Integrations

- **USB:** exploratory portable secure-element dev board for desktop / MCU use.
- **SPI:** common host-to-secure-element bus for embedded systems.
- **NFC:** a potential *future* product interface; not implied by the secure element itself. NFC requires separate hardware and interface/security design.
- **HTTPS / local peer network:** shipping signed bundles, with separate transport auth.
- **VCG:** contextual edges for device, source, observation, verifier, witnesses and authority.
- **Cardano:** periodic signed Merkle or batch commitments if there is a concrete need for shared immutable ordering.

## Design constraint

The authoritative trust registry must not be accepted simply because it arrived in the same JSON file as the event; an attacker could replace both. This starter provides a local allowlist only to teach the concept. A deployable design would pin or authenticate trust-root keys and handle key rotation, lifecycle and compromise.

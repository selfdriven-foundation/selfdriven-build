# 03 — Educational evidence protocol v0.1

**Status:** local experimentation profile, **not** an interoperable standard. No formal security audit. If independently interoperable implementations are required, adopt RFC 8785 JCS or a proven canonical CBOR profile after a design review.

## Event body

```json
{
  "protocol": "selfdriven.silicon.evidence.v0.1",
  "deviceId": "sdid:spki256:<BASE64URL_SHA256_OF_SPKI_DER>",
  "sequence": 1,
  "previousHash": null,
  "observedAt": "2026-11-16T01:02:03.000Z",
  "evidenceType": "energy.production.sample",
  "observation": {
    "sourceId": "simulated-meter-01",
    "wattHours": 1250,
    "intervalSeconds": 60
  }
}
```

The timestamp is **host-supplied**. The reading is **simulated**. The `deviceId` is a public-key fingerprint and **not** a real-world or independently verified DID. The demonstration currently accepts one specific `evidenceType` with three observation fields.

## Deriving cryptographic evidence

1. Validate the event body against the narrow v0.1 profile (`src/protocol.js`).
2. Encode as UTF-8 using the local deterministic JSON encoder: ASCII alphanumeric/underscore object field names sorted lexicographically; no floating-point numbers (only safe integers); normal JSON strings/booleans/null/arrays. **Not RFC 8785.**
3. Prefix the UTF-8 bytes with `selfdriven.silicon.evidence.v0.1\n` to separate this signing context from other use cases.
4. Calculate SHA-256 over the full prefixed bytes, represented as `sha256:<lowercase hex>`.
5. Sign **the same prefixed bytes** using Ed25519, not the hex digest.
6. Add a `proof` object containing signature, public key, hash and software/hardware provenance label.
7. The next event sets `previousHash` to the preceding event's `proof.eventHash`, and increments its sequence.

`publicKeySpki` is base64url of DER SubjectPublicKeyInfo (SPKI). `deviceId` is `sdid:spki256:` followed by base64url SHA-256 of this DER. These are project-specific labels, not standards-registered DID methods.

## Verification sequence

1. Reject unexpected fields and unsupported values, including unsupported algorithms.
2. Recompute key fingerprint to match `deviceId`.
3. Recompute the exact canonical event hash.
4. Verify Ed25519 signature using the included public key.
5. For an ordered stream, verify `sequence` and `previousHash` linkage.
6. Separately fetch an **authenticated** trust registry (demo supplies an unauthenticated local allowlist) and check enrolment, issuer, revocation and scope.
7. Separately assess measurement accuracy, time, calibration, origin and governing policy.

**Chain limitation:** A hash chain shows continuity only for the supplied set. A malicious signer can omit events or issue forks. To detect truncation or forks, maintain trusted previously observed heads/sequence checkpoints with independent witnesses or an authenticated log.

## Signer provenance

`signerType: 'software-demo'` is honest metadata, not verified security attestation. In a future hardware format, replace self-declared labels with a distinct attestation object whose manufacturer/end-user certificate chain, nonce and claims are independently checked. Never treat an arbitrary `signerType` string as proof of genuine hardware.

## Compatibility and evolution

- Treat new algorithms and protocol versions as explicit opt-in, not fallback.
- Design a versioned canonical profile before hardware production.
- Add a signed key-enrolment event, revocation and authorization policies as separate objects.
- Avoid putting raw personal data or precise household activity on a public blockchain.
- Define retention, deletion and consent independently from signature validity.

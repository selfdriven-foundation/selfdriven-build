# 01 — Vision and use cases

## The opportunity

Open silicon can allow communities not only to **use** digital infrastructure but to examine, own and govern important pieces of it. The near-term opportunity is not to replace existing CPUs: it is to provide a portable, low-power **hardware root for accountable participation**.

**North-star statement:** *An independently governed community should be able to know which of its devices made a claim, verify that the record has not been altered, and decide whether to trust or act on it.*

## Fit with selfdriven

| selfdriven area | Silicon contribution | Broader mechanism |
|---|---|---|
| Core | Device registration, access decisions, event provenance | Community entity/data model |
| Human | Portable credentials or user approval of sensitive actions | Self-sovereign participation and privacy |
| Octonomous | Protected identity and bounded authority for an autonomous Octo | Policy engines and human/community oversight |
| Infrastructure | Attested nodes, sensors, community energy and local compute | Physical devices and networks |
| Verified Context Graphs | Signed observations, referenced source/provenance | Verification beyond signatures |
| OnChain | Optional immutable checkpoints and commitments | Cardano/other chains where justified |
| Handshake | Human-readable addressing or naming, if selected | Names and routability; not cryptographic truth |

## Five use-case families

1. **Community energy:** signed energy observations, calibration provenance and local allocation records; physical metering assurance is a separate problem.
2. **Community infrastructure:** devices in local compute, telecommunications or sensing systems publish accountable state changes.
3. **Autonomous Octos:** authority constrained by policy; actions carry signatures and the community can review them.
4. **Human identity:** hardware-backed credential actions with consent and minimum disclosure; hardware does not by itself establish a person's real-world identity.
5. **Community contributions:** signatures on attestations of participation, with human or independent checks for legitimacy and fairness.

## 4Cs design lens

- **Curious:** fully documented starter experiments and inspectable verification algorithms.
- **Caring:** collect minimum data; no mandatory central surveillance; an accessible appeals process for incorrect records.
- **Constructive:** each workshop ends with an observable artefact and a real community problem to address.
- **Chill:** software-only exercises first; the project must remain useful without custom silicon.

## Out of scope for v0.1

- Making or shipping a production ASIC.
- Providing certified hardware security or compliance claims.
- Proving truthfulness of any real-world measurement.
- Issuing legal identities, consent credentials or financial instruments.
- Executing autonomous physical-world actions without a separate safety/policy system.
- A production Cardano integration.

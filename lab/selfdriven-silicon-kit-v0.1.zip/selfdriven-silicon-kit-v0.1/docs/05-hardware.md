# 05 — Hardware and open-silicon path

## Hardware options

| Route | Candidate | Why | Important limitation |
|---|---|---|---|
| 0. Software | Mac/PC running Node.js | Works immediately, no hardware spend | Keys are software-generated, no hardware assurance |
| 1. Existing secure element | TROPIC01 USB DevKit + host | Auditable secure-element design, Ed25519/P-256, published SDK | Requires integration and enrolment; DevKit is not a finished consumer product |
| 2. Embedded device | MCU/Raspberry Pi + secure element + suitable meter | End-to-end field prototype | Meter, firmware, power and enclosure need separate assurance |
| 3. Educational HDL | RTL event counter + simulator | First taste of chip design | Counter is volatile, not secure, not an identity chip |
| 4. Open PDK | SKY130 / GF180, OpenROAD + compatible flow | Physical layout and fabrication learning | PDK does not provide a secure element or security evaluation |
| 5. Custom secure ASIC | Carefully scoped IP and fabrication partner | Potential eventual cost/control benefits | High NRE, verification, power, test, ESD, tamper and supply-chain demands |

**Recommended first hardware experiment:** investigate TROPIC01 USB DevKit. Tropic Square documents its Ed25519 signing capability, USB/SPI evaluation options and SDK. Validate firmware revisions, security advisories, programming interfaces, signed key enrolment and availability before procurement.

## Practical hardware BOM for an initial workshop (not a quotation)

- Laptop with Node.js ≥ 20 and USB port.
- Optional: TROPIC01 USB DevKit; inspect official documentation first.
- Optional: a Raspberry Pi or MCU development board for SPI-based work.
- Optional: breadboard power/sensor *simulator*; use safe low-voltage sources only.
- Optional: logic analyser for SPI learning.
- Optional later: independently calibrated, legally suitable energy meter and electrical engineer for any mains-connected experimentation.

**Mains electricity safety:** Do not wire household mains to experimental breadboards or kits. Energy readings in this starter are simulated; real mains energy measurement should use appropriately certified equipment installed by a qualified professional in Australia.

## What a PDK actually contributes

A Process Design Kit supplies foundry-dependent design rules, technology/layer descriptions, device models and parasitic information for chip layout and verification. It does not contain a ready-made secure coprocessor. Physical design also needs RTL/IP, standard-cell libraries, synthesis, placement/routing, DRC/LVS, timing closure, fabrication preparation, test, packaging and software.

## Open silicon workflow

```text
RTL design (SystemVerilog) → functional simulation → synthesis
 → place & route with PDK → DRC/LVS/timing review
 → GDSII/OASIS handoff → fabrication/shuttle → bring-up/test
```

- OpenROAD-flow-scripts currently supports open platforms including SKY130, GF180 and SG13G2 (always check flow/version compatibility).
- Tiny Tapeout offers small shared silicon opportunities; open shuttles, supported PDKs, pricing and deadlines change.
- OpenTitan is a strong open silicon root-of-trust reference, but its full design is far more complex than a small educational shuttle tile.

## Scope for the **first custom circuit**

Start with a **non-secure event sequence block** (see `rtl/`). It exposes a counter increment input and overflow. In subsequent experiments, teach nonvolatile storage, tamper response, reset provenance and robust counters **before** considering a root of trust. Do not create a false impression that a taped-out counter is equivalent to a secure element.

## Implementation milestones

1. Choose a device family and review its datasheets, license, SDK and public security reports.
2. Port canonical body generation and signature requests through an explicit signing adapter.
3. Obtain signed evidence and independent key enrolment without extracting the private key.
4. Add per-device command authorization, access-control policy and witnessed checkpoints.
5. Test compromised-host scenarios and a sensor-validation mechanism.
6. Only then scope cost, custom IP ownership, fabrication and certification requirements.

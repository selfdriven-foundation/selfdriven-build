# 11 — v0.1 success criteria and backlog

## Already provided in this kit

- [x] Self-contained Node.js demonstration with no third-party packages.
- [x] Per-run Ed25519 identity and device fingerprint.
- [x] Three signed simulated energy-production observations.
- [x] SHA-256 linked event sequence.
- [x] Independent Node verifier and separate local device allowlist check.
- [x] Tests covering signature tampering, wrong key, order, duplicate and registry checks.
- [x] Illustrated hardware options and staged educational RTL.
- [x] Standalone browser verifier (modern browsers; fallback CLI).

## Still required before a field pilot

- [ ] Select community use case and obtain consent from a pilot owner.
- [ ] Agree an interoperable canonical format with test vectors and formal spec review.
- [ ] Implement genuine secure-element signing with non-exportable keys.
- [ ] Implement independently authenticated enrolment and revocation registry.
- [ ] Validate device claims (manufacturer/owner attestation) and key rotation.
- [ ] Independent measurement assurance and timestamp/sequence anchoring.
- [ ] Offline resynchronisation, fork detection and witnessed checkpoints.
- [ ] Data protection, security assessment and suitability for Australian use.
- [ ] VCG integration and optional Cardano anchoring, only if justified.

## Concrete acceptance demonstration

**Pass:** Two users can exchange an example event file, validate signatures and sequence, detect a modified watt-hour value, explain what key identity means, and distinguish `locally-listed` from independently trusted hardware attestation.

**Fail:** The design claims a signed number is a true physical measurement, that in-memory keys are silicon-backed, or that putting a hash on-chain validates the event.

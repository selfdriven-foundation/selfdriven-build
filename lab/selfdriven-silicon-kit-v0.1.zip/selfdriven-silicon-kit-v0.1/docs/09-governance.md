# 09 — Community governance and licensing

## Working principles

1. **Communities decide:** which observations are relevant, who may join, and how devices obtain authority.
2. **Inspectability:** verification algorithms, formats, test vectors and errors should be understandable without privileged tooling.
3. **Minimum necessary disclosure:** not every event should be public or on-chain.
4. **Revocation and correction:** support compromised devices, mistakes and disputed readings.
5. **No security theatre:** label software simulations, uncertified hardware and unvalidated measurements accurately.
6. **Portable implementation:** multiple manufacturers and device types can implement the same protocol.

## Proposed community decisions

- Approve the first problem and a responsible pilot owner.
- Define enrolment requirements and who controls the issuer key.
- Define what 'verified' means per use case (signature, device, source, calibration, independent witness).
- Decide how dispute resolution, privacy, retention and record correction operate.
- Choose who operates storage, offline relays and recovery processes.
- Define acceptable firmware, vendor and supply-chain review criteria.

## Suggested license approach (not a licence grant)

- **Code/protocol reference implementation:** consider Apache-2.0 for patent-aware open licensing or MIT if simpler terms are preferred.
- **Documentation/learning material:** consider Creative Commons BY 4.0.
- **Hardware design/RTL:** consider CERN-OHL-S-2.0 or CERN-OHL-P-2.0 depending on reciprocity goals.
- **Brand/marks:** manage separately via Foundation trademark and naming policy.

**Status:** These are proposals. No licence or Foundation approval has been granted by this draft. Before public repository publication, add the approved licence texts, copyright owners, contributor terms and third-party attribution rules.

## Starter workshop decision register

| Question | Default in this starter | Needs approval? |
|---|---|---|
| Project name | selfdriven Silicon Kit | Yes |
| First activity | Simulated community solar observation | Yes |
| Device format | Ed25519 + narrow deterministic JSON | Yes before interoperable v1 |
| Hardware | TROPIC01 as candidate | Yes before procurement |
| OnChain | Optional later | Yes |
| Public data | Minimal simulated-only examples | Yes for real data |
| Licensing | Proposals only | Yes |

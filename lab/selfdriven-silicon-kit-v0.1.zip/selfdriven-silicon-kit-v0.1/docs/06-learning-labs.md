# 06 — Learning labs

These labs are suitable for engineers, students, community technologists or non-specialist participants working together. Each has an explicit outcome and a question to discuss.

## Lab A — Identity without central accounts (20–30 min)

1. Install Node.js 20+.
2. Run `npm run demo`.
3. Inspect `examples/evidence.json`: identify `deviceId`, `proof.publicKeySpki`, and `proof.signature`.
4. Run `npm run verify`.
5. Run `npm run demo` a second time. Note that the device ID changes because the key is ephemeral.

**Question:** Who should be allowed to say that a new key belongs to a community-owned device?

## Lab B — Detect modification (15–20 min)

1. Open `examples/evidence.json` in a text editor and change a `wattHours` field.
2. Run `npm run verify` again.
3. Observe the hash/signature failure.
4. Recreate valid examples with `npm run demo`.

**Question:** Why does proving an unmodified signed value not prove that the sensor is accurate?

## Lab C — Understand trust registries (20–30 min)

1. Run `node src/verify.js examples/evidence.json` without the registry.
2. Run `npm run verify` with `examples/trust-registry.json`.
3. Set the registry device status to `revoked` and rerun.
4. Explain why a separately authenticated registry is needed in real deployments.

**Question:** Who governs enrolment and revocation, and how do participants appeal errors?

## Lab D — Browser verifier (20–30 min)

1. Open `web/index.html` locally in a modern browser.
2. Inspect the bundled sample evidence and browser-verification result.
3. Import the latest `examples/evidence.json` after regenerating it.
4. Press **Simulate tampering**, observe failure, and **Reset sample**.

**Question:** Should the local viewer send raw observations anywhere? (It does not.)

## Lab E — First RTL simulation (30–60 min)

Requires Icarus Verilog (`iverilog`) if available:

```bash
iverilog -g2012 -s tb_event_counter -o /tmp/sd-counter rtl/event_counter.sv rtl/tb_event_counter.sv
vvp /tmp/sd-counter
```

**Question:** Why is a counter that resets to zero *not* an anti-replay security primitive?

## Lab F — Hardware migration (future lab)

- Connect a selected secure-element development board through its vendor SDK.
- Replace software signing with a device-held non-exportable key.
- Independently enrol the device public key; if claimed, verify the hardware attestation evidence.
- Show signatures continue to validate with a hardware backend.
- Record precisely which security properties have been demonstrated versus assumed.

**Question:** How do we verify the difference between a hardware-backed signature and merely a software claim of hardware backing?

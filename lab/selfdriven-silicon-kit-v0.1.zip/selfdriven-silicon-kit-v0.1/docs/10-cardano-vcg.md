# 10 — Future Verified Context Graph and Cardano integration

**Everything in this file is a future design sketch, not implemented by the demo.**

## Suggested VCG context graph

```text
Community ─governs→ DeviceRegistry ─enrols→ Device
Device ─uses→ SigningKey ─signs→ EvidenceEvent
EvidenceEvent ─observes→ Resource
EvidenceEvent ─claims→ Reading
Sensor ─provided→ Reading
Verifier ─checked→ EvidenceEvent
IndependentWitness ─corroborates?→ Reading
GovernanceRule ─authorises?→ Action
BatchCommitment ─includesHash→ EvidenceEvent
```

Each edge should identify its evidence basis, issuer, time provenance and validation method. A signature validates a **claim**, not an edge labelled 'true' by default.

## Candidate proof envelope

- `evidenceHash`: deterministic hash from `proof.eventHash`.
- `deviceId`: pseudonymous key fingerprint.
- `validationResults`: signatures, issuer trust, source calibration, independent witness and relevant governance rules kept separately.
- `witnesses`: independently identified validators, each signing their claim and scope.
- `consentAndVisibility`: explicit metadata in the access-governed VCG layer rather than putting personal information on-chain.

## Optional Cardano anchoring

1. Produce a batch of event hashes that have already passed policy-relevant validation.
2. Build a Merkle tree under a **versioned, published** construction.
3. Store or submit a batch root and minimal public metadata on Cardano only when shared immutable ordering adds value.
4. Keep raw evidence and personal/sensitive attributes in appropriate off-chain storage.
5. Verify Merkle inclusion, transaction finality and relevant community rules independently.

Hash anchoring can demonstrate that an event existed no later than a confirmed checkpoint, subject to chain confirmation assumptions. It does **not** prove sensor truth, prevent earlier backdating, or imply the community endorses the claim.

## Autonomous Octo example

An Octo may propose an energy allocation or local compute scheduling action. A policy engine checks the resource budget and permissions; a protected signing key signs the approved action. Independent logs capture the proposal, authorization, execution receipt, outcomes and appeals. The chip does not decide policy or replace human governance.

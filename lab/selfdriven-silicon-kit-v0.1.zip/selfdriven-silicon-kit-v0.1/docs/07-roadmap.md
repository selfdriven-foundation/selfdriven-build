# 07 — Roadmap and decision gates

The durations below are **illustrative planning slices**, not delivery commitments.

| Stage | Indicative slice | Deliverable | Gate to advance |
|---|---|---|---|
| Discover | 1–2 workshops | A real community problem, target users, consent/governance assumptions | A community sponsor agrees the problem matters |
| Software proof | 1–2 weeks | Signed evidence demo, tests, browser verifier | Tampering/replay checks explained and independently reproduced |
| Hardware prototype | 2–6 weeks after hardware access | Secure element adapter, enrolment demo, key-retention check | Key remains non-exportable; claims independently validated |
| Field trial | Variable | Real-source measurements, audit, revocation, offline paths | Independent sensor validation, privacy and safety review |
| Open silicon learning | Parallel | RTL testbench + one supported layout flow | Simulation and DRC/timing evidence; disclosure of limitations |
| ASIC decision | Only after traction | Costed requirements, build-vs-buy analysis, security plan | Purpose/volume justify non-recurring engineering investment |

## Workstreams

1. **Protocol** — evidence encoding, chain semantics, signer adapters, multi-device collection.
2. **Silicon** — library/PDK learning, secure element evaluation, RTL simulation.
3. **Applications** — energy node, Octo event signing, VCG connections.
4. **Assurance** — identity lifecycle, security review, attestation, privacy and audit.
5. **Community** — docs, workshop kits, licence decisions, governance and participation.

## Build-vs-buy principle

Manufacturing a custom chip is not automatically more open or sovereign than using an auditable, existing component. Decide after testing whether independent ownership of the silicon **design**, **supply**, **production**, **firmware** or **cryptographic trust roots** is the actual requirement.

## Good first milestone

*Two independently operated computers verify that a simulated community node signed the same byte-for-byte observation history; the community can explain exactly what this does and does not prove.*

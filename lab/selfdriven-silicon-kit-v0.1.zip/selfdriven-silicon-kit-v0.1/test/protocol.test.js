'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { PROTOCOL, generateSoftwareSigner, createSignedEvent, verifyEvent, verifyChain, canonicalize, checkRegistry } = require('../src/protocol');
function fixture() {
  const signer = generateSoftwareSigner();
  const body = {
    protocol: PROTOCOL, deviceId: signer.deviceId, sequence: 1,
    previousHash: null, observedAt: '2026-11-16T01:02:03.000Z',
    evidenceType: 'energy.production.sample',
    observation: { sourceId: 'simulated-meter-01', wattHours: 1250, intervalSeconds: 60 }
  };
  return { signer, body, event: createSignedEvent(body, signer) };
}
test('canonical object key order independent', () => {
  assert.equal(canonicalize({ b: 2, a: 1 }), canonicalize({ a: 1, b: 2 }));
});
test('signed event and one-element chain verify', () => {
  const { event } = fixture();
  assert.equal(verifyEvent(event).valid, true);
  assert.equal(verifyChain([event]).valid, true);
});
test('changing a reading invalidates signature', () => {
  const { event } = fixture();
  const tampered = structuredClone(event);
  tampered.observation.wattHours = 99999;
  assert.equal(verifyEvent(tampered).valid, false);
});
test('wrong key/device identity is rejected', () => {
  const { event } = fixture();
  const other = generateSoftwareSigner();
  const tampered = structuredClone(event);
  tampered.proof.publicKeySpki = other.publicKeySpki;
  assert.equal(verifyEvent(tampered).valid, false);
});
test('sequence and previous hash protect ordering', () => {
  const { signer, event } = fixture();
  const next = createSignedEvent({ ...fixtureBodyFrom(event), sequence: 2, previousHash: event.proof.eventHash, observedAt: '2026-11-16T01:03:03.000Z' }, signer);
  assert.equal(verifyChain([event, next]).valid, true);
  assert.equal(verifyChain([next, event]).valid, false);
  assert.equal(verifyChain([event, event]).valid, false);
});
function fixtureBodyFrom(event) { const { proof, ...body } = event; return body; }
test('local trust registry is separately assessed', () => {
  const { event } = fixture();
  assert.equal(checkRegistry([event], null).status, 'unassessed');
  assert.equal(checkRegistry([event], { devices: [{ deviceId: event.deviceId, publicKeySpki: event.proof.publicKeySpki, status: 'active', assurance: 'software-demo' }] }).status, 'locally-listed');
});

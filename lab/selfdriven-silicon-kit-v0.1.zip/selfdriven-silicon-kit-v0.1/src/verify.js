'use strict';
const fs = require('node:fs');
const { verifyChain, checkRegistry } = require('./protocol');
function main() {
  const file = process.argv[2];
  if (!file) throw Error('Usage: node src/verify.js <evidence.json> [trust-registry.json]');
  const bundle = JSON.parse(fs.readFileSync(file, 'utf8'));
  const result = verifyChain(bundle.events);
  console.log(result.valid ? 'PASS: signed evidence and hash chain' : 'FAIL: ' + result.reason);
  if (!result.valid) { process.exitCode = 1; return; }
  const registry = process.argv[3] ? JSON.parse(fs.readFileSync(process.argv[3], 'utf8')) : null;
  const trust = checkRegistry(bundle.events, registry);
  console.log(`Registry: ${trust.status}${trust.assurance ? ` (${trust.assurance})` : ''}`);
  console.log('Reminder: a valid signature does not prove correct measurements, trusted time, secure hardware or authorisation.');
  if (trust.status === 'untrusted') process.exitCode = 2;
}
Promise.resolve().then(main).catch(err => { console.error(err.message); process.exitCode = 1; });

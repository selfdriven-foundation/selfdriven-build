'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { PROTOCOL, generateSoftwareSigner, createSignedEvent, verifyChain } = require('./protocol');

function main() {
  const signer = generateSoftwareSigner();
  const sample = [1200, 1260, 1320];
  let previousHash = null;
  const baseTime = Date.now() - 3 * 60000;
  const events = sample.map((wattHours, i) => {
    const body = {
      protocol: PROTOCOL,
      deviceId: signer.deviceId,
      sequence: i + 1,
      previousHash,
      observedAt: new Date(baseTime + i * 60000).toISOString(),
      evidenceType: 'energy.production.sample',
      observation: { sourceId: 'simulated-meter-01', wattHours, intervalSeconds: 60 }
    };
    const event = createSignedEvent(body, signer);
    previousHash = event.proof.eventHash;
    return event;
  });
  const result = verifyChain(events);
  if (!result.valid) throw Error(result.reason);
  const examples = path.join(__dirname, '..', 'examples');
  fs.mkdirSync(examples, { recursive: true });
  fs.writeFileSync(path.join(examples, 'evidence.json'), JSON.stringify({ events }, null, 2) + '\n');
  const registry = { notice: 'Educational local allowlist only; neither independently authenticated nor hardware attested', devices: [{
    deviceId: signer.deviceId, publicKeySpki: signer.publicKeySpki,
    name: 'Community solar demo node', status: 'active', assurance: 'software-demo'
  }] };
  fs.writeFileSync(path.join(examples, 'trust-registry.json'), JSON.stringify(registry, null, 2) + '\n');
  console.log(`Generated ${events.length} signed simulated energy observations`);
  console.log(`Device: ${signer.deviceId}`);
  console.log(`Verified hash-chain head: ${result.head}`);
  console.log('Wrote examples/evidence.json and examples/trust-registry.json');
  console.log('Private signing key existed only in memory; it was not saved.');
}
Promise.resolve().then(main).catch(err => { console.error(err); process.exitCode = 1; });

# selfdriven Silicon Kit

**Version:** 0.1 — foundation / developer starter kit  
**Status:** Exploratory concept + working software simulation (not a fabricated chip)  
**Prepared:** 16 November 2026  
**For:** selfdriven.build × selfdriven.network × open-silicon collaborators

> Hardware-backed trust and verifiable activity for people, communities and autonomous systems.

## Why

People and communities should be able to own, understand and govern the computing infrastructure they depend on. Silicon can support this by providing independent device identity, protecting signing keys, and making observations or actions independently verifiable. This kit takes a practical route: **prototype the protocol, validate it on existing hardware, then consider open custom silicon**.

**Four principles:** Curious (learn how it works), Caring (minimise surveillance and harm), Constructive (make something verifiable and useful), Chill (keep the entry barrier low).

## What is included

| Part | Contents | Status |
|---|---|---|
| Learn | Vision, architecture, hardware/PDK guide, learning labs | Draft guidance |
| Build | Runnable Node.js Ed25519 signed-evidence demo | Working / tested |
| Verify | Node CLI + single-file browser verifier | Working prototype |
| Silicon | Illustrative SystemVerilog event counter + testbench | Educational RTL only |
| Actuate | Proposed connections to Verified Context Graphs and Cardano | Design only |
| Govern | Trust model, privacy, threat model, roadmap | Draft guidance |

**Important:** The software demo uses an ephemeral *software-generated* key. It does not claim device attestation, tamper resistance, trusted metering, trusted time, or secure key storage. A signed observation proves only that a key signed those bytes. The locally provided registry is an illustrative allowlist, not an independently trusted trust service.

## Quick start (Node.js 20+, no npm dependencies)

```bash
cd selfdriven-silicon-kit-v0.1
npm run demo
npm run verify
npm test
```

- `npm run demo` generates a new in-memory Ed25519 key and three simulated energy readings, then writes public examples into `examples/`.
- `npm run verify` validates signatures, hash-chaining and the **separate local** device allowlist.
- `npm test` exercises signature and tamper verification.
- Open [`web/index.html`](web/index.html) directly in a modern browser to inspect the example events and load your own `examples/evidence.json` / `examples/trust-registry.json` files. Browser Ed25519 verification requires compatible Web Crypto APIs and a secure context. The Node CLI remains the fallback.

**Do not deploy the demo unchanged to production or use it for financial settlement, metering or safety-critical control.**

## Proposed first use case

A community solar node collects a watt-hour reading from a **simulated** meter, signs a sequence of observations, and lets independent software verify the signatures and detect modifications. Later stages can replace the in-memory key with a protected signing key in a real secure element and use an independently validated revenue-grade meter.

```text
[Community system / meter]
           │ observation (initially simulated)
           ▼
[Host: Raspberry Pi / MCU / local Octo]
           │ sign(bytes)                       ┌──────────────────────┐
           ├──────────────────────────────────►│ Secure element       │
           │                                   │ (future phase)       │
           ▼                                   └──────────────────────┘
[Signed Evidence: identity + event + sequence + hash + signature]
           │
           ▼
[Independent verifier + trusted device registry]
           │
           ├──► [Verified Context Graph (proposed)]
           └──► [Optional Cardano batch hash anchor (proposed)]
```

## Starter decisions

1. **Hardware neutrality:** signing interface supports software and future silicon adapters.
2. **Ed25519 demo:** a well-supported protocol learning choice, **not** a claim that every hardware device supports it.
3. **Evidence, not truth:** verification, sensor calibration, provenance, consent and governance remain separate.
4. **No permanent personal identifiers in the demonstration:** a new key pair is created each run and is not saved.
5. **Community governance by design:** device enrolment, revocation and permissions must be externally managed.
6. **No blockchain dependency in the basic loop:** Cardano anchoring is optional, and never substitutes for validating a measurement.
7. **Open participation:** no ASIC is required to begin using or contributing to this kit.

## Repository map

- [`docs/01-vision.md`](docs/01-vision.md) — story, outcomes, values, use cases
- [`docs/02-architecture.md`](docs/02-architecture.md) — roles, layers, interfaces
- [`docs/03-protocol.md`](docs/03-protocol.md) — evidence format and verification
- [`docs/04-threat-model.md`](docs/04-threat-model.md) — security and privacy
- [`docs/05-hardware.md`](docs/05-hardware.md) — component choices / PDKs / ASIC roadmap
- [`docs/06-learning-labs.md`](docs/06-learning-labs.md) — practical teaching labs
- [`docs/07-roadmap.md`](docs/07-roadmap.md) — staged development and decisions
- [`docs/08-references.md`](docs/08-references.md) — authoritative source links
- [`docs/09-governance.md`](docs/09-governance.md) — governance model and licensing choices
- [`docs/10-cardano-vcg.md`](docs/10-cardano-vcg.md) — proposed downstream integration
- [`docs/11-success-criteria.md`](docs/11-success-criteria.md) — measurable MVP acceptance
- `src/` — software signer / event generator / independent verifier
- `test/` — Node.js tests
- `schemas/` — educational JSON Schemas
- `rtl/` — minimal educational event counter (NOT security-hardened)
- `web/index.html` — offline-friendly standalone browser verifier
- `examples/` — regenerated public sample files (no private keys)

## Next build choices

- **Lowest cost / learning:** Node software demo → browser verifier → RTL counter simulation.
- **Closest to real trust:** Node demo → TROPIC01 USB DevKit + host → independently enrolled device registry.
- **Open silicon exploration:** toy RTL → FPGA simulation → OpenROAD/OpenLane with SKY130/GF180 → small multi-project wafer shuttle.

These are complementary tracks, not a commitment to manufacture a custom security chip. For realistic tamper-resistance, proven silicon and professional security evaluation are materially harder than a small educational tapeout.

## Questions for the first workshop

- Which first activity matters: energy, environmental sensing, credentialled humans, autonomous Octos, or community asset exchange?
- Who is the **issuer** of a device identity? Who may enrol, suspend or revoke it?
- What measurements can legitimately be considered independently verified?
- Where do personal data, consent and access controls live?
- What evidence must stay local, what can be shared, and what (if anything) needs an on-chain anchor?
- Which components can be openly published, and what licenses should the Foundation approve?

## Provisional name

**selfdriven Silicon Kit** is a working name; **OCTO Silicon** and **selfdriven Core: Silicon Edition** are alternative concepts, not selected brands.

No Foundation endorsement, ownership assignment or publishing license is inferred from this draft. See governance document before public release.

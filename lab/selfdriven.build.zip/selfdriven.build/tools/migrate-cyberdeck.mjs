#!/usr/bin/env node
// migrate-cyberdeck.mjs
// Moves the cyberdeck project from the selfdriven.you repo to the selfdriven.build repo.
//
//   node tools/migrate-cyberdeck.mjs --you ../selfdriven.you            # dry run: prints every change
//   node tools/migrate-cyberdeck.mjs --you ../selfdriven.you --apply    # writes the changes
//
// What it does
//   1. Copies the two build guides into selfdriven.build, unchanged except for links:
//        /cyberdeck-build-guide         -> /cyberdeck/field-deck/
//        /cyberdeck-pocket-build-guide  -> /cyberdeck/pocket-deck/
//      Links to the other cyberdeck pages follow the move; links to pages that stay on
//      selfdriven.you become absolute https://selfdriven.you/... links; the nav wordmark
//      becomes selfdriven.build; title, canonical and og:url point at the new home.
//   2. Copies every /assets/ file the selfdriven.build pages use (audio, PDFs, .skill
//      packages, logo) from selfdriven.you. Originals stay, so old download links keep working.
//   3. Replaces the three old selfdriven.you pages with redirect stubs (hash preserved).
//   4. Points every remaining selfdriven.you link at the new URLs, and drops the old
//      URLs from selfdriven.you's sitemap.xml.
//
// No dependencies. Node 18+. Safe to re-run: stubs and identical copies are skipped.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const YOU = 'https://selfdriven.you';
const BUILD = 'https://selfdriven.build';

// old path on selfdriven.you -> new path on selfdriven.build
const MOVES = [
  { old: '/cyberdeck-the-idea', next: '/cyberdeck/', copy: false, hash: {} },          // rebuilt as cyberdeck/index.html
  { old: '/cyberdeck-build-guide', next: '/cyberdeck/field-deck/', copy: true, hash: {} },
  { old: '/cyberdeck-pocket-build-guide', next: '/cyberdeck/pocket-deck/', copy: true, hash: {} },
];

const SKIP_DIRS = new Set(['.git', 'node_modules', '_site', '.jekyll-cache', '.sass-cache', 'vendor', '.bundle']);
const ATTR_RE = /\b(href|src|poster|data-src|action)\s*=\s*(["'])(.*?)\2/gi;
const CSS_URL_RE = /url\(\s*(["']?)([^"')]+)\1\s*\)/gi;
const META_CONTENT_RE = /(<meta\b[^>]*?\bcontent\s*=\s*)(["'])(https?:\/\/(?:www\.)?selfdriven\.you\/[^"']*)\2/gi;

// ---------- args ----------
const argv = process.argv.slice(2);
const flag = (n) => argv.includes(n);
const opt = (n) => { const i = argv.indexOf(n); return i >= 0 ? argv[i + 1] : undefined; };
const here = path.dirname(fileURLToPath(import.meta.url));
const youRoot = opt('--you') && path.resolve(opt('--you'));
const buildRoot = path.resolve(opt('--build') || path.join(here, '..'));
const APPLY = flag('--apply');
const FORCE = flag('--force');

if (!youRoot || flag('--help')) {
  console.log('usage: node tools/migrate-cyberdeck.mjs --you <selfdriven.you repo> [--build <selfdriven.build repo>] [--apply] [--force]');
  process.exit(youRoot ? 0 : 1);
}
for (const [name, dir] of [['--you', youRoot], ['--build', buildRoot]]) {
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) { console.error(`✗ ${name} ${dir} is not a folder`); process.exit(1); }
}

// ---------- output ----------
const log = { changes: 0, warnings: [] };
const head = (t) => console.log(`\n── ${t}`);
const say = (s) => console.log('  ' + s);
const change = (s) => { log.changes++; say((APPLY ? '✓ ' : '· ') + s); };
const warn = (s) => { log.warnings.push(s); say('! ' + s); };
const rel = (root, p) => path.relative(root, p) || '.';

function write(file, text) {
  if (!APPLY) return;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, text);
}
function copy(from, to) {
  if (!APPLY) return;
  fs.mkdirSync(path.dirname(to), { recursive: true });
  fs.copyFileSync(from, to);
}

// ---------- helpers ----------
function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name)) walk(path.join(dir, e.name), out); }
    else out.push(path.join(dir, e.name));
  }
  return out;
}

// The URL a repo file is served at, e.g. "cyberdeck-build-guide.html" -> "/cyberdeck-build-guide".
function servedPath(root, file) {
  let p = '/' + rel(root, file).split(path.sep).join('/');
  p = p.replace(/\.(html|md|markdown)$/i, '');
  if (p.endsWith('/index')) p = p.slice(0, -5);
  return p;
}

function normalise(pathname) {
  let p = pathname.replace(/\/index\.html$/i, '/').replace(/\.html$/i, '');
  if (p.length > 1) p = p.replace(/\/+$/, '');
  return p;
}

const isYouHost = (u) => /^(www\.)?selfdriven\.you$/i.test(u.hostname);
const moveFor = (pathname) => MOVES.find((m) => m.old === normalise(pathname));
const mapHash = (m, hash) => (hash && m.hash[hash.slice(1)] ? '#' + m.hash[hash.slice(1)] : hash);

function resolve(raw, basePath) {
  const v = raw.trim();
  if (!v || /^(#|mailto:|tel:|sms:|data:|javascript:|blob:)/i.test(v) || v.includes('{{') || v.includes('{%')) return null;
  let u;
  try { u = new URL(v, YOU + basePath); } catch { return null; }
  if (!/^https?:$/.test(u.protocol) || !isYouHost(u)) return null;
  return u;
}

// Rewrite one reference inside a page that now lives on selfdriven.build.
function rewriteForBuild(raw, basePath, assets) {
  const u = resolve(raw, basePath);
  if (!u) return raw;
  const m = moveFor(u.pathname);
  if (m) return m.next + u.search + mapHash(m, u.hash);
  if (u.pathname.startsWith('/assets/')) { assets.add(decodeURIComponent(u.pathname)); return u.pathname + u.search + u.hash; }
  return YOU + u.pathname + u.search + u.hash; // a page that stays on selfdriven.you
}

// Rewrite one reference inside a page that stays on selfdriven.you.
function rewriteForYou(raw, basePath) {
  const u = resolve(raw, basePath);
  if (!u) return raw;
  const m = moveFor(u.pathname);
  return m ? BUILD + m.next + u.search + mapHash(m, u.hash) : raw;
}

function findSource(oldPath) {
  const name = oldPath.slice(1);
  const direct = [`${name}.html`, `${name}/index.html`, `${name}.md`, `${name}/index.md`].map((c) => path.join(youRoot, c));
  const hit = direct.find((f) => fs.existsSync(f));
  if (hit) return hit;
  // Fallback: a file anywhere in the repo that is served at this path (e.g. _pages/, or a permalink).
  for (const f of walk(youRoot)) {
    if (!/\.(html|md)$/i.test(f)) continue;
    const text = fs.readFileSync(f, 'utf8');
    const pm = text.match(/^---[\s\S]*?\npermalink:\s*["']?([^\s"']+)["']?[\s\S]*?\n---/);
    if (pm && normalise(pm[1]) === oldPath) return f;
    if (path.basename(f).replace(/\.(html|md)$/i, '') === name) return f;
  }
  return null;
}

const isStub = (text) => /data-moved-to=/.test(text);

function stub(newUrl, hashMap) {
  return `<!doctype html>
<html lang="en" data-moved-to="${newUrl}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Moved to selfdriven.build</title>
<link rel="canonical" href="${newUrl}">
<meta name="robots" content="noindex, follow">
<meta http-equiv="refresh" content="0; url=${newUrl}">
<script>(function(){var m=${JSON.stringify(hashMap)},h=location.hash.slice(1);location.replace(${JSON.stringify(newUrl)}+(h?'#'+(m[h]||h):''));})();</script>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;box-sizing:border-box;background:#09090f;color:#f0eeff;font:17px/1.6 'DM Sans',system-ui,sans-serif}p{max-width:34ch}a{color:#00e5a0}</style>
</head>
<body><p>The cyberdeck project has moved to <a href="${newUrl}">selfdriven.build</a>. Be Constructive. Let's Build!</p></body>
</html>
`;
}

// ---------- run ----------
console.log(`${APPLY ? 'APPLYING' : 'DRY RUN (add --apply to write)'}\n  selfdriven.you   ${youRoot}\n  selfdriven.build ${buildRoot}`);

const sources = new Map();
for (const m of MOVES) sources.set(m, findSource(m.old));

// 1. Copy the guides
head('1 · Copy build guides into selfdriven.build');
const assets = new Set();
for (const m of MOVES.filter((x) => x.copy)) {
  const src = sources.get(m);
  if (!src) { warn(`${m.old}: no source file found in selfdriven.you`); continue; }
  let text = fs.readFileSync(src, 'utf8');
  if (isStub(text)) {
    const done = fs.existsSync(path.join(buildRoot, m.next, 'index.html'));
    if (done) say(`= ${rel(youRoot, src)} already moved`);
    else warn(`${rel(youRoot, src)} is a redirect stub but ${m.next} is missing here. Restore the original from git and re-run.`);
    continue;
  }
  if (/^---\s*\n/.test(text) || /\{%|\{\{\s/.test(text)) warn(`${rel(youRoot, src)} uses Jekyll front matter or Liquid. Check it renders on selfdriven.build after the move.`);

  const base = servedPath(youRoot, src);
  text = text.replace(ATTR_RE, (all, attr, q, v) => `${attr}=${q}${rewriteForBuild(v, base, assets)}${q}`);
  text = text.replace(/<style\b[\s\S]*?<\/style>/gi, (block) =>
    block.replace(CSS_URL_RE, (all, q, v) => `url(${q}${rewriteForBuild(v, base, assets)}${q})`));
  text = text.replace(META_CONTENT_RE, (all, pre, q, v) => {
    const u = new URL(v); const m2 = moveFor(u.pathname);
    if (m2) return `${pre}${q}${BUILD}${m2.next}${q}`;
    if (u.pathname.startsWith('/assets/')) { assets.add(decodeURIComponent(u.pathname)); return `${pre}${q}${BUILD}${u.pathname}${q}`; }
    return all;
  });
  // Nav wordmark: first <nav> (or <header>) now belongs to selfdriven.build.
  text = text.replace(/<(nav|header)\b[\s\S]*?<\/\1>/i, (block) =>
    block.replace(/<em>\s*\.you\s*<\/em>/gi, '<em>.build</em>')
         .replace(/href=(["'])https:\/\/selfdriven\.you\/?\1/gi, 'href=$1/$1'));
  text = text.replace(/(\s*[·|\-–—]\s*)selfdriven\.you(\s*<\/title>)/i, '$1selfdriven.build$2');
  text = text.replace(/<link\b[^>]*rel=["']canonical["'][^>]*>\s*/gi, '');
  text = text.replace(/<\/head>/i, `<link rel="canonical" href="${BUILD}${m.next}">\n</head>`);

  const dest = path.join(buildRoot, m.next, 'index.html');
  if (fs.existsSync(dest)) {
    const now = fs.readFileSync(dest, 'utf8');
    if (now === text) { say(`= ${rel(buildRoot, dest)} already up to date`); continue; }
    if (!FORCE) { warn(`${rel(buildRoot, dest)} exists and differs. Re-run with --force to overwrite.`); continue; }
  }
  change(`${rel(youRoot, src)}  →  ${rel(buildRoot, dest)}`);
  write(dest, text);
  const left = (text.match(/selfdriven\.you/g) || []).length;
  if (left) say(`  ${left} remaining mention(s) of "selfdriven.you" in copy or companion links; review by eye.`);
}

// 2. Assets used by any selfdriven.build page
head('2 · Copy assets from selfdriven.you');
for (const f of walk(buildRoot).filter((f) => f.endsWith('.html'))) {
  const text = fs.readFileSync(f, 'utf8');
  for (const [, a] of text.matchAll(/["'(](?:https:\/\/selfdriven\.build)?(\/assets\/[^"'()\s?#]+)/g)) assets.add(decodeURIComponent(a));
}
// Pages written in this run are not on disk during a dry run; their assets were collected in step 1.
for (const a of [...assets].sort()) {
  const to = path.join(buildRoot, a), from = path.join(youRoot, a);
  if (fs.existsSync(to)) { say(`= ${a}`); continue; }
  if (!fs.existsSync(from)) { warn(`${a} is not in either repo`); continue; }
  change(`${a}  (${(fs.statSync(from).size / 1024).toFixed(0)} KB)`);
  copy(from, to);
}

// 3. Redirect stubs on selfdriven.you
head('3 · Leave redirect stubs on selfdriven.you');
const stubFiles = new Set();
for (const m of MOVES) {
  const src = sources.get(m);
  const url = BUILD + m.next;
  if (!src) { warn(`${m.old}: no page found to replace. Add a redirect to ${url} by hand.`); continue; }
  stubFiles.add(src);
  const text = fs.readFileSync(src, 'utf8');
  if (isStub(text)) { say(`= ${rel(youRoot, src)} already redirects`); continue; }
  if (!src.endsWith('.html')) { warn(`${rel(youRoot, src)} is Markdown. Replace it by hand with an HTML redirect to ${url}.`); continue; }
  change(`${rel(youRoot, src)}  ⇢  ${url}`);
  write(src, stub(url, m.hash));
}

// 4. Point remaining selfdriven.you links at the new home
head('4 · Update links across selfdriven.you');
for (const f of walk(youRoot)) {
  if (stubFiles.has(f) || !/\.(html|md)$/i.test(f)) continue;
  const text = fs.readFileSync(f, 'utf8');
  const base = servedPath(youRoot, f);
  const hits = [];
  const out = text.replace(ATTR_RE, (all, attr, q, v) => {
    const n = rewriteForYou(v, base);
    if (n !== v) hits.push(`${v} → ${n}`);
    return `${attr}=${q}${n}${q}`;
  }).replace(/\]\(([^)\s]+)\)/g, (all, v) => { // Markdown links
    const n = rewriteForYou(v, base);
    if (n !== v) hits.push(`${v} → ${n}`);
    return `](${n})`;
  });
  if (!hits.length) continue;
  change(`${rel(youRoot, f)}`);
  hits.forEach((h) => say(`    ${h}`));
  write(f, out);
}
const sitemap = path.join(youRoot, 'sitemap.xml');
if (fs.existsSync(sitemap)) {
  const xml = fs.readFileSync(sitemap, 'utf8');
  const dropped = [];
  const out = xml.replace(/\s*<url>\s*<loc>([^<]+)<\/loc>[\s\S]*?<\/url>/g, (all, loc) => {
    try { if (moveFor(new URL(loc.trim()).pathname)) { dropped.push(loc.trim()); return ''; } } catch {}
    return all;
  });
  if (dropped.length) { change(`sitemap.xml: drop ${dropped.join(', ')}`); write(sitemap, out); }
}

// Summary
head('Summary');
say(`${log.changes} change(s) ${APPLY ? 'written' : 'planned'}, ${log.warnings.length} warning(s).`);
if (!APPLY) say('Nothing was written. Re-run with --apply.');
else say('Commit both repos. selfdriven.build goes live once its DNS and GitHub Pages custom domain are set (see README.md).');
process.exit(log.warnings.length && APPLY ? 2 : 0);
